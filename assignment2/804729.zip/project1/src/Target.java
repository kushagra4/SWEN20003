import org.newdawn.slick.Input;

//package project1;

public class Target extends Tiles {
	public Target(float x, float y) {
		super("res/Target.png", x, y);
	}
}
