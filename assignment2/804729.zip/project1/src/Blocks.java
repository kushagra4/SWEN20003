import org.newdawn.slick.Graphics;

public class Blocks extends Sprite {

	public Blocks(String image_src, float x, float y) {
		super(image_src, x, y);
		// TODO Auto-generated constructor stub
	}

	public void render(Graphics g) {
		super.render(g);
	}

}
