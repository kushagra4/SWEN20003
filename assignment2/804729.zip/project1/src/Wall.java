//package project1;

public class Wall extends Tiles {
	public Wall(float x, float y) {
		super("res/wall.png", x, y);
	}
}
