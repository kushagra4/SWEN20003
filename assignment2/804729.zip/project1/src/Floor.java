//package project1;

public class Floor extends Tiles {
	public Floor(float x, float y) {
		super("res/floor.png", x, y);
	}
}
