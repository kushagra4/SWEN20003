import org.newdawn.slick.Graphics;

public class Tiles extends Sprite{

	public Tiles(String image_src, float x, float y) {
		super(image_src, x, y);
		// TODO Auto-generated constructor stub
	}

	public void render(Graphics g) {
		super.render(g);
	}
}
