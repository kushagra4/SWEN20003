
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

public abstract class Units extends Sprite {

	public Units(String image_src, float x, float y) {
		super(image_src, x, y);
		// TODO Auto-generated constructor stub
	}

	public void render(Graphics g) {
		super.render(g);
	}

}
